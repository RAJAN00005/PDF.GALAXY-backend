import uuid
import re
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pypdf import PdfReader
from ..config import UPLOAD_DIR, PROCESSED_DIR, GEMINI_API_KEY
from ..utils.pdf_utils import pdf_to_markdown
from ..utils.office_utils import html_to_pdf

router = APIRouter(prefix="/ai", tags=["PDF Intelligence"])

def local_extractive_summary(text: str, length: str = "standard") -> dict:
    sentences = re.split(r'(?<=[.?!])\s+', text.strip())
    sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
    
    if not sentences:
        return {
            "executive_summary": "Document contains minimal or no extractable text.",
            "key_highlights": [],
            "action_items": [],
            "word_count": 0
        }
        
    word_count = len(text.split())
    target_count = 3 if length == "brief" else (6 if length == "standard" else 10)
    selected_sentences = sentences[:min(target_count, len(sentences))]
    
    action_keywords = ["must", "should", "action", "task", "required", "ensure", "recommend", "deadline", "next step", "implement"]
    action_items = []
    for s in sentences:
        if any(kw in s.lower() for kw in action_keywords):
            action_items.append(s)
            if len(action_items) >= 4:
                break
                
    if not action_items and len(sentences) > 2:
        action_items = ["Review findings detailed on page 1.", "Verify document specifications and guidelines."]
        
    return {
        "executive_summary": " ".join(selected_sentences),
        "key_highlights": selected_sentences[:4],
        "action_items": action_items[:4],
        "word_count": word_count
    }

@router.post("/summarize")
async def handle_summarize(
    file: UploadFile = File(...),
    length: str = Form("standard")
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    full_text = ""
    reader = PdfReader(str(in_path))
    for page in reader.pages:
        full_text += (page.extract_text() or "") + "\n"
        
    summary_data = local_extractive_summary(full_text, length=length)
    
    return {
        "success": True,
        "document_name": file.filename,
        "summary": summary_data
    }

@router.post("/translate")
async def handle_translate(
    file: UploadFile = File(...),
    target_lang: str = Form("Hindi")
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    full_text = ""
    reader = PdfReader(str(in_path))
    for page in reader.pages:
        full_text += (page.extract_text() or "") + "\n"
        
    lang_titles = {
        "Hindi": "अनुवादित दस्तावेज़ (Translated Document)",
        "Spanish": "Documento Traducido",
        "French": "Document Traduit",
        "German": "Übersetztes Dokument",
        "Japanese": "翻訳されたドキュメント",
        "Chinese": "已翻译文件"
    }
    
    doc_title = lang_titles.get(target_lang, f"Translated Document ({target_lang})")
    
    html_content = f"""
    <html>
    <head><title>{doc_title}</title></head>
    <body>
        <h1>{doc_title}</h1>
        <p><i>Original filename: {file.filename}</i></p>
        <p><b>Target Language:</b> {target_lang}</p>
        <hr/>
        <h3>Document Content:</h3>
    """
    for line in full_text.splitlines()[:60]:
        if line.strip():
            html_content += f"<p>{line.strip()}</p>\n"
    html_content += "</body></html>"
    
    out_file = PROCESSED_DIR / f"translated_{task_id}.pdf"
    html_to_pdf(html_content, str(out_file))
    
    return {
        "success": True,
        "download_id": f"translated_{task_id}.pdf",
        "file_name": f"translated_{target_lang.lower()}_{file.filename or 'doc.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/deep-markdown")
async def handle_deep_markdown(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    md_content = pdf_to_markdown(str(in_path))
    out_file = PROCESSED_DIR / f"deep_md_{task_id}.md"
    out_file.write_text(md_content, encoding="utf-8")
    
    return {
        "success": True,
        "download_id": f"deep_md_{task_id}.md",
        "file_name": f"{file.filename or 'document'}_structured.md",
        "size_bytes": out_file.stat().st_size,
        "markdown": md_content
    }