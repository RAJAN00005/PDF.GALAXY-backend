import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException
from ..config import UPLOAD_DIR
from ..utils.pdf_utils import compare_pdfs

router = APIRouter(prefix="/compare", tags=["Compare"])

@router.post("/compare")
async def handle_compare(
    file1: UploadFile = File(...),
    file2: UploadFile = File(...)
):
    task_id = str(uuid.uuid4())
    path1 = UPLOAD_DIR / f"compare_1_{task_id}.pdf"
    path2 = UPLOAD_DIR / f"compare_2_{task_id}.pdf"
    
    path1.write_bytes(await file1.read())
    path2.write_bytes(await file2.read())
    
    comparison = compare_pdfs(str(path1), str(path2))
    
    return {
        "success": True,
        "doc1_name": file1.filename,
        "doc2_name": file2.filename,
        "comparison": comparison
    }
