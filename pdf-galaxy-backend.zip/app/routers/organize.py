import uuid
import json
from pathlib import Path
from typing import List
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from ..config import UPLOAD_DIR, PROCESSED_DIR
from ..utils.pdf_utils import merge_pdfs, split_pdf, remove_pages, extract_pages, organize_pdf

router = APIRouter(prefix="/organize", tags=["Organize"])

@router.post("/merge")
async def handle_merge(files: List[UploadFile] = File(...)):
    if not files or len(files) < 2:
        raise HTTPException(status_code=400, detail="At least 2 files are required to merge.")
    
    saved_paths = []
    task_id = str(uuid.uuid4())
    
    for idx, f in enumerate(files):
        ext = Path(f.filename).suffix or ".pdf"
        dest = UPLOAD_DIR / f"{task_id}_{idx}{ext}"
        content = await f.read()
        dest.write_bytes(content)
        saved_paths.append(str(dest))
        
    out_file = PROCESSED_DIR / f"merged_{task_id}.pdf"
    merge_pdfs(saved_paths, str(out_file))
    
    return {
        "success": True,
        "download_id": f"merged_{task_id}.pdf",
        "file_name": "merged_document.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/split")
async def handle_split(
    file: UploadFile = File(...),
    ranges: str = Form("all") # "all" or "1-3, 4-6"
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    is_all = ranges.strip().lower() == "all"
    out_ext = ".zip" if is_all else ".pdf"
    out_file = PROCESSED_DIR / f"split_{task_id}{out_ext}"
    
    split_pdf(str(in_path), ranges, str(out_file))
    
    return {
        "success": True,
        "download_id": f"split_{task_id}{out_ext}",
        "file_name": f"split_result{out_ext}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/remove-pages")
async def handle_remove_pages(
    file: UploadFile = File(...),
    pages: str = Form(...) # comma separated 1-based page numbers e.g. "1,3"
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    pages_list = [int(p.strip()) for p in pages.split(",") if p.strip().isdigit()]
    out_file = PROCESSED_DIR / f"removed_{task_id}.pdf"
    
    remove_pages(str(in_path), pages_list, str(out_file))
    
    return {
        "success": True,
        "download_id": f"removed_{task_id}.pdf",
        "file_name": "cleaned_document.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/extract-pages")
async def handle_extract_pages(
    file: UploadFile = File(...),
    pages: str = Form(...) # comma separated 1-based page numbers e.g. "1,2,5"
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    pages_list = [int(p.strip()) for p in pages.split(",") if p.strip().isdigit()]
    out_file = PROCESSED_DIR / f"extracted_{task_id}.pdf"
    
    extract_pages(str(in_path), pages_list, str(out_file))
    
    return {
        "success": True,
        "download_id": f"extracted_{task_id}.pdf",
        "file_name": "extracted_pages.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/organize")
async def handle_organize(
    file: UploadFile = File(...),
    actions: str = Form(...) # JSON string of [{'page': 1, 'rotation': 90}, ...]
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    actions_list = json.loads(actions)
    out_file = PROCESSED_DIR / f"organized_{task_id}.pdf"
    
    organize_pdf(str(in_path), actions_list, str(out_file))
    
    return {
        "success": True,
        "download_id": f"organized_{task_id}.pdf",
        "file_name": "organized_document.pdf",
        "size_bytes": out_file.stat().st_size
    }
