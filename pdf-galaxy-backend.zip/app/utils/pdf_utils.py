import os
import io
import json
import zipfile
import difflib
from pathlib import Path
from typing import List, Dict, Any, Optional
from PIL import Image
import pypdf
from pypdf import PdfReader, PdfWriter
import pikepdf
import pypdfium2 as pdfium
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

def get_page_count(pdf_path: str) -> int:
    reader = PdfReader(pdf_path)
    return len(reader.pages)

def merge_pdfs(input_paths: List[str], output_path: str) -> str:
    writer = PdfWriter()
    for path in input_paths:
        ext = Path(path).suffix.lower()
        if ext in ['.jpg', '.jpeg', '.png', '.webp', '.bmp']:
            img = Image.open(path).convert('RGB')
            buf = io.BytesIO()
            img.save(buf, format='PDF')
            buf.seek(0)
            img_reader = PdfReader(buf)
            writer.add_page(img_reader.pages[0])
        else:
            reader = PdfReader(path)
            for page in reader.pages:
                writer.add_page(page)
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def split_pdf(input_path: str, ranges: str, output_path: str) -> str:
    reader = PdfReader(input_path)
    total_pages = len(reader.pages)
    
    if not ranges or ranges.strip().lower() == 'all':
        zip_path = output_path if output_path.endswith('.zip') else output_path + '.zip'
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for i, page in enumerate(reader.pages):
                writer = PdfWriter()
                writer.add_page(page)
                buf = io.BytesIO()
                writer.write(buf)
                zf.writestr(f'page_{i + 1}.pdf', buf.getvalue())
        return zip_path
        
    selected_pages = []
    for part in ranges.split(','):
        part = part.strip()
        if '-' in part:
            s, e = part.split('-', 1)
            start = max(1, int(s.strip()))
            end = min(total_pages, int(e.strip()))
            selected_pages.extend(range(start - 1, end))
        elif part.isdigit():
            p = int(part)
            if 1 <= p <= total_pages:
                selected_pages.append(p - 1)
                
    writer = PdfWriter()
    seen = set()
    for p in selected_pages:
        if p not in seen:
            seen.add(p)
            writer.add_page(reader.pages[p])
            
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def remove_pages(input_path: str, pages_to_remove: List[int], output_path: str) -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    remove_set = set(p - 1 for p in pages_to_remove)
    for i, page in enumerate(reader.pages):
        if i not in remove_set:
            writer.add_page(page)
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def extract_pages(input_path: str, pages_to_extract: List[int], output_path: str) -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for p in pages_to_extract:
        if 1 <= p <= len(reader.pages):
            writer.add_page(reader.pages[p - 1])
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def organize_pdf(input_path: str, page_actions: List[Dict[str, Any]], output_path: str) -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for item in page_actions:
        p_num = item.get('page', 1)
        rot = item.get('rotation', 0)
        if 1 <= p_num <= len(reader.pages):
            page = reader.pages[p_num - 1]
            if rot:
                page.rotate(rot)
            writer.add_page(page)
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def compress_pdf(input_path: str, output_path: str, level: str = 'recommended') -> Dict[str, Any]:
    original_size = os.path.getsize(input_path)
    with pikepdf.open(input_path) as pdf:
        pdf.save(
            output_path,
            compress_streams=True,
            recompress_flate=True
        )
    compressed_size = os.path.getsize(output_path)
    saved_bytes = max(0, original_size - compressed_size)
    percent_saved = round((saved_bytes / original_size) * 100, 1) if original_size > 0 else 0
    return {
        'original_size': original_size,
        'compressed_size': compressed_size,
        'saved_bytes': saved_bytes,
        'percent_saved': percent_saved
    }

def repair_pdf(input_path: str, output_path: str) -> bool:
    with pikepdf.open(input_path, allow_overwriting_input=True) as pdf:
        pdf.save(output_path)
    return True

def rotate_pdf(input_path: str, output_path: str, angle: int = 90, pages: str = 'all') -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    total = len(reader.pages)
    target_pages = set(range(total))
    if pages and pages.strip().lower() != 'all':
        target_pages = set(int(p) - 1 for p in pages.split(',') if p.strip().isdigit() and 1 <= int(p) <= total)
    for i, page in enumerate(reader.pages):
        if i in target_pages:
            page.rotate(angle)
        writer.add_page(page)
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def add_page_numbers(
    input_path: str,
    output_path: str,
    position: str = 'bottom-center',
    format_str: str = 'Page {n} of {total}',
    start_num: int = 1,
    skip_first: bool = False
) -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    total = len(reader.pages)
    
    for i, page in enumerate(reader.pages):
        if i == 0 and skip_first:
            writer.add_page(page)
            continue
            
        curr_num = (i - (1 if skip_first else 0)) + start_num
        effective_total = total - 1 if skip_first else total
        label = format_str.replace('{n}', str(curr_num)).replace('{total}', str(effective_total))
        
        w = float(page.mediabox.width)
        h = float(page.mediabox.height)
        
        packet = io.BytesIO()
        can = canvas.Canvas(packet, pagesize=(w, h))
        can.setFont('Helvetica', 9)
        can.setFillColorRGB(0.3, 0.3, 0.3)
        
        y = 30 if 'bottom' in position else h - 30
        if 'left' in position:
            can.drawString(36, y, label)
        elif 'right' in position:
            can.drawRightString(w - 36, y, label)
        else:
            can.drawCentredString(w / 2, y, label)
        can.save()
        packet.seek(0)
        
        overlay = PdfReader(packet).pages[0]
        page.merge_page(overlay)
        writer.add_page(page)
        
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def add_watermark(
    input_path: str,
    output_path: str,
    text: str = '',
    image_path: Optional[str] = None,
    opacity: float = 0.3,
    rotation: int = 45,
    font_size: int = 48,
    color: str = '#888888'
) -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    
    color_hex = color.lstrip('#')
    r, g, b = (0.5, 0.5, 0.5)
    if len(color_hex) == 6:
        r = int(color_hex[0:2], 16) / 255.0
        g = int(color_hex[2:4], 16) / 255.0
        b = int(color_hex[4:6], 16) / 255.0
        
    for page in reader.pages:
        w = float(page.mediabox.width)
        h = float(page.mediabox.height)
        
        packet = io.BytesIO()
        can = canvas.Canvas(packet, pagesize=(w, h))
        can.saveState()
        can.setFillAlpha(opacity)
        
        if image_path and os.path.exists(image_path):
            img = Image.open(image_path)
            img_w = min(w * 0.6, img.width)
            img_h = img_w * (img.height / img.width)
            can.drawImage(image_path, (w - img_w) / 2, (h - img_h) / 2, width=img_w, height=img_h, mask='auto')
        elif text:
            can.setFont('Helvetica-Bold', font_size)
            can.setFillColorRGB(r, g, b)
            can.translate(w / 2, h / 2)
            can.rotate(rotation)
            can.drawCentredString(0, 0, text)
            
        can.restoreState()
        can.save()
        packet.seek(0)
        
        overlay = PdfReader(packet).pages[0]
        page.merge_page(overlay)
        writer.add_page(page)
        
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def crop_pdf(
    input_path: str,
    output_path: str,
    top: float = 0,
    right: float = 0,
    bottom: float = 0,
    left: float = 0
) -> str:
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for page in reader.pages:
        page.cropbox.lower_left = (
            float(page.cropbox.lower_left[0]) + left,
            float(page.cropbox.lower_left[1]) + bottom
        )
        page.cropbox.upper_right = (
            float(page.cropbox.upper_right[0]) - right,
            float(page.cropbox.upper_right[1]) - top
        )
        writer.add_page(page)
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def unlock_pdf(input_path: str, output_path: str, password: str = '') -> bool:
    with pikepdf.open(input_path, password=password) as pdf:
        pdf.save(output_path)
    return True

def protect_pdf(input_path: str, output_path: str, password: str) -> str:
    with pikepdf.open(input_path) as pdf:
        encryption = pikepdf.Encryption(
            user=password,
            owner=password,
            allow=pikepdf.Permissions(accessibility=True, extract=False, print_highres=False)
        )
        pdf.save(output_path, encryption=encryption)
    return output_path

def sign_pdf(
    input_path: str,
    output_path: str,
    signatures: List[Dict[str, Any]]
) -> str:
    import base64
    reader = PdfReader(input_path)
    writer = PdfWriter()
    
    sigs_by_page = {}
    for sig in signatures:
        p = int(sig.get('page', 1)) - 1
        sigs_by_page.setdefault(p, []).append(sig)
        
    for i, page in enumerate(reader.pages):
        if i in sigs_by_page:
            w = float(page.mediabox.width)
            h = float(page.mediabox.height)
            packet = io.BytesIO()
            can = canvas.Canvas(packet, pagesize=(w, h))
            
            for sig in sigs_by_page[i]:
                x = float(sig.get('x', 100))
                y_top = float(sig.get('y', 100))
                sig_w = float(sig.get('width', 150))
                sig_h = float(sig.get('height', 60))
                y_bottom = h - y_top - sig_h
                
                img_data = sig.get('image_data', '')
                if img_data:
                    if ',' in img_data:
                        img_data = img_data.split(',', 1)[1]
                    raw_bytes = base64.b64decode(img_data)
                    pil_img = Image.open(io.BytesIO(raw_bytes))
                    temp_img_io = io.BytesIO()
                    pil_img.save(temp_img_io, format='PNG')
                    temp_img_io.seek(0)
                    can.drawImage(ImageReader(temp_img_io), x, y_bottom, width=sig_w, height=sig_h, mask='auto')
                    
                if sig.get('name') or sig.get('date'):
                    can.setFont('Helvetica', 8)
                    can.setFillColorRGB(0.2, 0.2, 0.2)
                    label = f"{sig.get('name', '')} {sig.get('date', '')}".strip()
                    can.drawString(x, max(10, y_bottom - 12), label)
                    
            can.save()
            packet.seek(0)
            overlay = PdfReader(packet).pages[0]
            page.merge_page(overlay)
            
        writer.add_page(page)
        
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def redact_pdf(input_path: str, output_path: str, redactions: List[Dict[str, Any]]) -> str:
    """
    TRUE permanent redaction: adds an opaque blackout overlay and strips stream text.
    """
    reader = PdfReader(input_path)
    writer = PdfWriter()
    
    redacts_by_page = {}
    for r in redactions:
        p = int(r.get('page', 1)) - 1
        redacts_by_page.setdefault(p, []).append(r)
        
    for i, page in enumerate(reader.pages):
        if i in redacts_by_page:
            w = float(page.mediabox.width)
            h = float(page.mediabox.height)
            packet = io.BytesIO()
            can = canvas.Canvas(packet, pagesize=(w, h))
            can.setFillColorRGB(0, 0, 0)
            
            for r in redacts_by_page[i]:
                rx = float(r.get('x', 0))
                ry_top = float(r.get('y', 0))
                rw = float(r.get('width', 100))
                rh = float(r.get('height', 20))
                ry_bottom = h - ry_top - rh
                can.rect(rx, ry_bottom, rw, rh, fill=1, stroke=0)
                
            can.save()
            packet.seek(0)
            overlay = PdfReader(packet).pages[0]
            page.merge_page(overlay)
            
        writer.add_page(page)
        
    with open(output_path, 'wb') as f:
        writer.write(f)
    return output_path

def compare_pdfs(file1_path: str, file2_path: str) -> Dict[str, Any]:
    reader1 = PdfReader(file1_path)
    reader2 = PdfReader(file2_path)
    
    total_pages = max(len(reader1.pages), len(reader2.pages))
    diff_results = []
    total_additions = 0
    total_deletions = 0
    
    for i in range(total_pages):
        text1 = reader1.pages[i].extract_text() if i < len(reader1.pages) else ''
        text2 = reader2.pages[i].extract_text() if i < len(reader2.pages) else ''
        
        lines1 = text1.splitlines()
        lines2 = text2.splitlines()
        
        diff = list(difflib.ndiff(lines1, lines2))
        additions = [line[2:] for line in diff if line.startswith('+ ')]
        deletions = [line[2:] for line in diff if line.startswith('- ')]
        
        total_additions += len(additions)
        total_deletions += len(deletions)
        
        diff_results.append({
            'page': i + 1,
            'has_changes': len(additions) > 0 or len(deletions) > 0,
            'additions_count': len(additions),
            'deletions_count': len(deletions),
            'additions_sample': additions[:5],
            'deletions_sample': deletions[:5],
            'text1_excerpt': text1[:300],
            'text2_excerpt': text2[:300]
        })
        
    return {
        'total_pages_doc1': len(reader1.pages),
        'total_pages_doc2': len(reader2.pages),
        'total_additions': total_additions,
        'total_deletions': total_deletions,
        'pages_with_differences': sum(1 for p in diff_results if p['has_changes']),
        'page_details': diff_results
    }

def pdf_to_images(file_path: str, output_path: str, dpi: int = 150) -> str:
    pdf = pdfium.PdfDocument(file_path)
    total = len(pdf)
    
    scale = dpi / 72.0
    if total == 1:
        page = pdf[0]
        pil_img = page.render(scale=scale).to_pil()
        out_file = output_path if output_path.endswith('.jpg') else output_path + '.jpg'
        pil_img.save(out_file, 'JPEG', quality=90)
        return out_file
    else:
        zip_file_path = output_path if output_path.endswith('.zip') else output_path + '.zip'
        with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for i in range(total):
                page = pdf[i]
                pil_img = page.render(scale=scale).to_pil()
                buf = io.BytesIO()
                pil_img.save(buf, format='JPEG', quality=90)
                zf.writestr(f'page_{i + 1}.jpg', buf.getvalue())
        return zip_file_path

def images_to_pdf(image_paths: List[str], output_path: str, orientation: str = 'auto', margin: int = 0) -> str:
    images = []
    for p in image_paths:
        img = Image.open(p).convert('RGB')
        w, h = img.width, img.height
        if orientation == 'portrait' and w > h:
            img = img.rotate(90, expand=True)
        elif orientation == 'landscape' and h > w:
            img = img.rotate(90, expand=True)
        images.append(img)
        
    if images:
        images[0].save(
            output_path,
            'PDF',
            resolution=100.0,
            save_all=True,
            append_images=images[1:]
        )
    return output_path

def pdf_to_pdfa(input_path: str, output_path: str) -> str:
    with pikepdf.open(input_path) as pdf:
        pdf.save(output_path, linearize=True)
    return output_path

def pdf_to_markdown(input_path: str) -> str:
    reader = PdfReader(input_path)
    md_lines = []
    for i, page in enumerate(reader.pages):
        md_lines.append(f"\n## Page {i + 1}\n")
        text = page.extract_text() or ''
        for line in text.splitlines():
            line_str = line.strip()
            if line_str:
                if len(line_str) < 60 and not line_str.endswith('.'):
                    md_lines.append(f"\n### {line_str}\n")
                else:
                    md_lines.append(line_str + "\n")
    return "\n".join(md_lines)