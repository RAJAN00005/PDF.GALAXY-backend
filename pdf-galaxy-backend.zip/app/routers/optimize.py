import uuid
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from ..config import UPLOAD_DIR, PROCESSED_DIR
from ..utils.pdf_utils import compress_pdf, repair_pdf
from ..utils.office_utils import ocr_pdf

router = APIRouter(prefix="/optimize", tags=["Optimize"])

@router.post("/compress")
async def handle_compress(
    file: UploadFile = File(...),
    level: str = Form("recommended") # "low", "recommended", "extreme"
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"compressed_{task_id}.pdf"
    stats = compress_pdf(str(in_path), str(out_file), level=level)
    
    return {
        "success": True,
        "download_id": f"compressed_{task_id}.pdf",
        "file_name": f"compressed_{file.filename or 'document.pdf'}",
        "stats": stats
    }

@router.post("/repair")
async def handle_repair(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"repaired_{task_id}.pdf"
    success = repair_pdf(str(in_path), str(out_file))
    
    return {
        "success": success,
        "download_id": f"repaired_{task_id}.pdf",
        "file_name": f"repaired_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/ocr")
async def handle_ocr(
    file: UploadFile = File(...),
    language: str = Form("eng") # "eng", "hin", "spa", "fra", "deu"
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"ocr_{task_id}.pdf"
    ocr_pdf(str(in_path), str(out_file), language=language)
    
    return {
        "success": True,
        "download_id": f"ocr_{task_id}.pdf",
        "file_name": f"searchable_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }
