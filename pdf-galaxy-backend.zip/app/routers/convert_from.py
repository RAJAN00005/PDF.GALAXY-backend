import uuid
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from ..config import UPLOAD_DIR, PROCESSED_DIR
from ..utils.pdf_utils import pdf_to_images, pdf_to_pdfa, pdf_to_markdown
from ..utils.office_utils import pdf_to_docx, pdf_to_pptx, pdf_to_excel

router = APIRouter(prefix="/convert-from", tags=["Convert FROM PDF"])

@router.post("/pdf-to-jpg")
async def handle_pdf_to_jpg(
    file: UploadFile = File(...),
    dpi: int = Form(150)
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_base = str(PROCESSED_DIR / f"images_{task_id}")
    final_output = pdf_to_images(str(in_path), out_base, dpi=dpi)
    out_file = Path(final_output)
    
    return {
        "success": True,
        "download_id": out_file.name,
        "file_name": f"{Path(file.filename or 'document').stem}_images{out_file.suffix}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/pdf-to-word")
async def handle_pdf_to_word(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"document_{task_id}.docx"
    pdf_to_docx(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"document_{task_id}.docx",
        "file_name": f"{Path(file.filename or 'document').stem}.docx",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/pdf-to-powerpoint")
async def handle_pdf_to_powerpoint(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"presentation_{task_id}.pptx"
    pdf_to_pptx(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"presentation_{task_id}.pptx",
        "file_name": f"{Path(file.filename or 'presentation').stem}.pptx",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/pdf-to-excel")
async def handle_pdf_to_excel(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"data_{task_id}.xlsx"
    pdf_to_excel(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"data_{task_id}.xlsx",
        "file_name": f"{Path(file.filename or 'table_data').stem}.xlsx",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/pdf-to-pdfa")
async def handle_pdf_to_pdfa(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"archival_{task_id}.pdf"
    pdf_to_pdfa(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"archival_{task_id}.pdf",
        "file_name": f"{Path(file.filename or 'document').stem}_PDF_A.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/pdf-to-markdown")
async def handle_pdf_to_markdown(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    md_content = pdf_to_markdown(str(in_path))
    out_file = PROCESSED_DIR / f"extracted_{task_id}.md"
    out_file.write_text(md_content, encoding="utf-8")
    
    return {
        "success": True,
        "download_id": f"extracted_{task_id}.md",
        "file_name": f"{Path(file.filename or 'document').stem}.md",
        "size_bytes": out_file.stat().st_size,
        "markdown_preview": md_content[:2000]
    }
