import uuid
import json
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from ..config import UPLOAD_DIR, PROCESSED_DIR
from ..utils.pdf_utils import unlock_pdf, protect_pdf, sign_pdf, redact_pdf

router = APIRouter(prefix="/security", tags=["PDF Security"])

@router.post("/unlock")
async def handle_unlock(
    file: UploadFile = File(...),
    password: str = Form(...)
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"unlocked_{task_id}.pdf"
    try:
        unlock_pdf(str(in_path), str(out_file), password=password)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
        
    return {
        "success": True,
        "download_id": f"unlocked_{task_id}.pdf",
        "file_name": f"unlocked_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/protect")
async def handle_protect(
    file: UploadFile = File(...),
    password: str = Form(...)
):
    if not password:
        raise HTTPException(status_code=400, detail="Password is required.")
        
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"protected_{task_id}.pdf"
    protect_pdf(str(in_path), str(out_file), password=password)
    
    return {
        "success": True,
        "download_id": f"protected_{task_id}.pdf",
        "file_name": f"protected_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/sign")
async def handle_sign(
    file: UploadFile = File(...),
    signatures: str = Form(...) # JSON list of signature specifications
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    sig_list = json.loads(signatures)
    out_file = PROCESSED_DIR / f"signed_{task_id}.pdf"
    sign_pdf(str(in_path), str(out_file), signatures=sig_list)
    
    return {
        "success": True,
        "download_id": f"signed_{task_id}.pdf",
        "file_name": f"signed_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/redact")
async def handle_redact(
    file: UploadFile = File(...),
    redactions: str = Form(...) # JSON list of areas to strip
):
    """
    TRUE REDACTION: Uses PyMuPDF apply_redactions() to permanently
    strip and erase text, font characters, vectors, and bitmap pixels
    from the PDF stream so that no tool can recover the redacted content.
    """
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    redactions_list = json.loads(redactions)
    out_file = PROCESSED_DIR / f"redacted_{task_id}.pdf"
    redact_pdf(str(in_path), str(out_file), redactions=redactions_list)
    
    return {
        "success": True,
        "download_id": f"redacted_{task_id}.pdf",
        "file_name": f"redacted_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size,
        "message": "Sensitive content has been permanently stripped from the PDF file."
    }
