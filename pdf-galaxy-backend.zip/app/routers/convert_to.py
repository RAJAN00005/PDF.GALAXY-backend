import uuid
import httpx
from pathlib import Path
from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from ..config import UPLOAD_DIR, PROCESSED_DIR
from ..utils.pdf_utils import images_to_pdf
from ..utils.office_utils import docx_to_pdf, pptx_to_pdf, excel_to_pdf, html_to_pdf

router = APIRouter(prefix="/convert-to", tags=["Convert TO PDF"])

@router.post("/jpg-to-pdf")
async def handle_jpg_to_pdf(
    files: List[UploadFile] = File(...),
    orientation: str = Form("auto"), # auto, portrait, landscape
    margin: int = Form(0)
):
    if not files:
        raise HTTPException(status_code=400, detail="No images provided.")
        
    task_id = str(uuid.uuid4())
    image_paths = []
    for idx, f in enumerate(files):
        ext = Path(f.filename).suffix or ".jpg"
        p = UPLOAD_DIR / f"img_{task_id}_{idx}{ext}"
        p.write_bytes(await f.read())
        image_paths.append(str(p))
        
    out_file = PROCESSED_DIR / f"images_{task_id}.pdf"
    images_to_pdf(image_paths, str(out_file), orientation=orientation, margin=margin)
    
    return {
        "success": True,
        "download_id": f"images_{task_id}.pdf",
        "file_name": "converted_images.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/word-to-pdf")
async def handle_word_to_pdf(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"word_{task_id}.docx"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"doc_{task_id}.pdf"
    docx_to_pdf(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"doc_{task_id}.pdf",
        "file_name": f"{Path(file.filename or 'document').stem}.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/powerpoint-to-pdf")
async def handle_pptx_to_pdf(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"ppt_{task_id}.pptx"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"presentation_{task_id}.pdf"
    pptx_to_pdf(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"presentation_{task_id}.pdf",
        "file_name": f"{Path(file.filename or 'presentation').stem}.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/excel-to-pdf")
async def handle_excel_to_pdf(file: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"excel_{task_id}.xlsx"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"spreadsheet_{task_id}.pdf"
    excel_to_pdf(str(in_path), str(out_file))
    
    return {
        "success": True,
        "download_id": f"spreadsheet_{task_id}.pdf",
        "file_name": f"{Path(file.filename or 'spreadsheet').stem}.pdf",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/html-to-pdf")
async def handle_html_to_pdf(
    file: Optional[UploadFile] = File(None),
    url: Optional[str] = Form(None)
):
    task_id = str(uuid.uuid4())
    html_content = ""
    
    if url and url.strip():
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                res = await client.get(url.strip())
                html_content = res.text
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to fetch webpage: {e}")
    elif file:
        raw_bytes = await file.read()
        html_content = raw_bytes.decode("utf-8", errors="ignore")
    else:
        raise HTTPException(status_code=400, detail="Please supply an HTML file or a website URL.")
        
    out_file = PROCESSED_DIR / f"web_{task_id}.pdf"
    html_to_pdf(html_content, str(out_file))
    
    return {
        "success": True,
        "download_id": f"web_{task_id}.pdf",
        "file_name": "converted_webpage.pdf",
        "size_bytes": out_file.stat().st_size
    }
