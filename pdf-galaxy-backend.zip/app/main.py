import asyncio
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from .config import PROCESSED_DIR
from .cleaner import start_cleanup_loop
from .routers import organize, optimize, convert_to, convert_from, edit, security, compare, ai

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start auto-deletion cleanup task
    cleanup_task = asyncio.create_task(start_cleanup_loop(interval_seconds=600))
    yield
    cleanup_task.cancel()

app = FastAPI(
    title="pdf.galaxy Microservice",
    description="Real file processing microservice powering all 34 tools of pdf.galaxy",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount all routers under /api
app.include_router(organize.router, prefix="/api")
app.include_router(optimize.router, prefix="/api")
app.include_router(convert_to.router, prefix="/api")
app.include_router(convert_from.router, prefix="/api")
app.include_router(edit.router, prefix="/api")
app.include_router(security.router, prefix="/api")
app.include_router(compare.router, prefix="/api")
app.include_router(ai.router, prefix="/api")

@app.get("/api/health")
async def health_check():
    return {
        "status": "online",
        "service": "pdf.galaxy",
        "version": "1.0.0",
        "tools_supported": 34
    }

@app.get("/api/download/{file_id}")
async def download_file(file_id: str):
    # Prevent path traversal
    safe_name = Path(file_id).name
    file_path = PROCESSED_DIR / safe_name
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Requested file has expired or does not exist.")
        
    media_type = "application/octet-stream"
    if safe_name.endswith(".pdf"):
        media_type = "application/pdf"
    elif safe_name.endswith(".zip"):
        media_type = "application/zip"
    elif safe_name.endswith(".docx"):
        media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    elif safe_name.endswith(".xlsx"):
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif safe_name.endswith(".pptx"):
        media_type = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    elif safe_name.endswith(".jpg") or safe_name.endswith(".jpeg"):
        media_type = "image/jpeg"
    elif safe_name.endswith(".md"):
        media_type = "text/markdown"
        
    return FileResponse(
        path=str(file_path),
        filename=safe_name,
        media_type=media_type
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=False)
