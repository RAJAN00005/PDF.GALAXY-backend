import uuid
import json
import base64
import io
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from ..config import UPLOAD_DIR, PROCESSED_DIR
from ..utils.pdf_utils import rotate_pdf, add_page_numbers, add_watermark, crop_pdf

router = APIRouter(prefix="/edit", tags=["Edit PDF"])

@router.post("/rotate")
async def handle_rotate(
    file: UploadFile = File(...),
    angle: int = Form(90),
    pages: str = Form("all")
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"rotated_{task_id}.pdf"
    rotate_pdf(str(in_path), str(out_file), angle=angle, pages=pages)
    
    return {
        "success": True,
        "download_id": f"rotated_{task_id}.pdf",
        "file_name": f"rotated_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/add-page-numbers")
async def handle_page_numbers(
    file: UploadFile = File(...),
    position: str = Form("bottom-center"),
    format_str: str = Form("Page {n} of {total}"),
    start_num: int = Form(1),
    skip_first: bool = Form(False)
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"numbered_{task_id}.pdf"
    add_page_numbers(
        str(in_path),
        str(out_file),
        position=position,
        format_str=format_str,
        start_num=start_num,
        skip_first=skip_first
    )
    
    return {
        "success": True,
        "download_id": f"numbered_{task_id}.pdf",
        "file_name": f"numbered_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/add-watermark")
async def handle_watermark(
    file: UploadFile = File(...),
    text: str = Form("CONFIDENTIAL"),
    watermark_image: Optional[UploadFile] = File(None),
    font_size: int = Form(48),
    rotation: int = Form(45),
    color: str = Form("#888888")
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    img_path = None
    if watermark_image:
        img_dest = UPLOAD_DIR / f"wm_img_{task_id}_{watermark_image.filename}"
        img_dest.write_bytes(await watermark_image.read())
        img_path = str(img_dest)
        
    out_file = PROCESSED_DIR / f"watermarked_{task_id}.pdf"
    add_watermark(
        str(in_path),
        str(out_file),
        text=text,
        image_path=img_path,
        font_size=font_size,
        rotation=rotation,
        color=color
    )
    
    return {
        "success": True,
        "download_id": f"watermarked_{task_id}.pdf",
        "file_name": f"watermarked_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/crop")
async def handle_crop(
    file: UploadFile = File(...),
    top: float = Form(0),
    right: float = Form(0),
    bottom: float = Form(0),
    left: float = Form(0)
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    out_file = PROCESSED_DIR / f"cropped_{task_id}.pdf"
    crop_pdf(str(in_path), str(out_file), top=top, right=right, bottom=bottom, left=left)
    
    return {
        "success": True,
        "download_id": f"cropped_{task_id}.pdf",
        "file_name": f"cropped_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/edit-canvas")
async def handle_edit_canvas(
    file: UploadFile = File(...),
    annotations: str = Form(...) # JSON of [{page: 1, type: 'text'|'rectangle', ...}]
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    annots_list = json.loads(annotations)
    out_file = PROCESSED_DIR / f"edited_{task_id}.pdf"
    
    reader = PdfReader(str(in_path))
    writer = PdfWriter()
    
    annots_by_page = {}
    for a in annots_list:
        p = int(a.get("page", 1)) - 1
        annots_by_page.setdefault(p, []).append(a)
        
    for i, page in enumerate(reader.pages):
        if i in annots_by_page:
            w = float(page.mediabox.width)
            h = float(page.mediabox.height)
            packet = io.BytesIO()
            can = canvas.Canvas(packet, pagesize=(w, h))
            
            for item in annots_by_page[i]:
                kind = item.get("type", "text")
                if kind == "text":
                    text = item.get("text", "")
                    x = float(item.get("x", 50))
                    y_top = float(item.get("y", 50))
                    size = float(item.get("fontSize", 12))
                    can.setFont("Helvetica", size)
                    can.setFillColorRGB(0.1, 0.1, 0.1)
                    can.drawString(x, h - y_top, text)
                elif kind == "rectangle":
                    x = float(item.get("x", 50))
                    y_top = float(item.get("y", 50))
                    rw = float(item.get("width", 100))
                    rh = float(item.get("height", 60))
                    can.setStrokeColorRGB(0.3, 0.3, 0.8)
                    can.setLineWidth(1.5)
                    can.rect(x, h - y_top - rh, rw, rh, fill=0, stroke=1)
                    
            can.save()
            packet.seek(0)
            overlay = PdfReader(packet).pages[0]
            page.merge_page(overlay)
            
        writer.add_page(page)
        
    with open(str(out_file), "wb") as f:
        writer.write(f)
        
    return {
        "success": True,
        "download_id": f"edited_{task_id}.pdf",
        "file_name": f"edited_{file.filename or 'document.pdf'}",
        "size_bytes": out_file.stat().st_size
    }

@router.post("/pdf-forms")
async def handle_pdf_forms(
    file: UploadFile = File(...),
    field_data: Optional[str] = Form(None)
):
    task_id = str(uuid.uuid4())
    in_path = UPLOAD_DIR / f"input_{task_id}.pdf"
    in_path.write_bytes(await file.read())
    
    reader = PdfReader(str(in_path))
    fields_found = []
    
    fields = reader.get_fields()
    if fields:
        for name, obj in fields.items():
            fields_found.append({
                "name": name,
                "type": str(obj.get("/FT", "text")),
                "value": str(obj.get("/V", ""))
            })
            
    if field_data:
        writer = PdfWriter()
        writer.append(reader)
        values = json.loads(field_data)
        for page in writer.pages:
            writer.update_page_form_field_values(page, values)
            
        out_file = PROCESSED_DIR / f"filled_form_{task_id}.pdf"
        with open(str(out_file), "wb") as f:
            writer.write(f)
            
        return {
            "success": True,
            "download_id": f"filled_form_{task_id}.pdf",
            "file_name": f"filled_{file.filename or 'form.pdf'}",
            "fields": fields_found
        }
        
    return {
        "success": True,
        "fields": fields_found,
        "message": f"Found {len(fields_found)} form fields in document."
    }